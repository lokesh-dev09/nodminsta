(function () {
  'use strict';
  if (window.__dmonly || !window.DMOnly) return;
  window.__dmonly = true;

  var B = window.DMOnly;
  var HOME = '/direct/inbox/';
  var BLOCK_CHAT_VIDEO = true;   // true = no video plays or shows anywhere in chats (this is what stops reels)

  function inChats() {
    return location.pathname.indexOf('/direct') === 0;
  }

  // ---------- No video inside chats: a tapped reel has nothing to show or play ----------
  function silence(video) {
    try { video.muted = true; video.pause(); } catch (e) {}
  }
  function sweepVideos() {
    var root = document.documentElement;
    if (!root) return;
    var on = BLOCK_CHAT_VIDEO && inChats();
    if (on !== root.classList.contains('dmonly-chats')) root.classList.toggle('dmonly-chats', on);
    if (!on) return;
    var videos = document.querySelectorAll('video');
    for (var i = 0; i < videos.length; i++) {
      if (!videos[i].paused || !videos[i].muted) silence(videos[i]);
    }
  }
  ['play', 'playing'].forEach(function (type) {
    document.addEventListener(type, function (e) {
      if (BLOCK_CHAT_VIDEO && inChats() && e.target && e.target.tagName === 'VIDEO') silence(e.target);
    }, true);
  });
  setInterval(sweepVideos, 250);

  function allowed(path) {
    try { return B.isAllowed(path); } catch (e) { return true; }
  }
  function state() {
    try { return JSON.parse(B.state()); } catch (e) { return { me: '', users: [] }; }
  }
  function segments(path) {
    return path.split('/').filter(Boolean).map(function (s) { return s.toLowerCase(); });
  }
  function onOwnProfile(me) {
    var seg = segments(location.pathname);
    return !!me && seg.length === 1 && seg[0] === me;
  }

  // ---------- Route guard (the app also enforces this natively) ----------
  var leaving = false;
  function guard() {
    if (leaving || allowed(location.pathname)) return;
    leaving = true;
    try { document.documentElement.style.visibility = 'hidden'; } catch (e) {}
    location.replace(HOME);
  }
  ['pushState', 'replaceState'].forEach(function (fn) {
    var original = history[fn];
    history[fn] = function () {
      var result = original.apply(this, arguments);
      guard();
      return result;
    };
  });
  window.addEventListener('popstate', guard);
  window.addEventListener('hashchange', guard);
  setInterval(guard, 200);
  guard();

  // ---------- Tap filter: blocked links do nothing ----------
  function filterTap(e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a || a.closest('#dmonly-panel')) return;
    var url;
    try { url = new URL(a.getAttribute('href'), location.href); } catch (err) { return; }
    if (url.origin !== location.origin) return;

    // Posts become openable only when tapped from your own profile grid
    var me = state().me;
    if (onOwnProfile(me)) {
      var seg = segments(url.pathname);
      var id = null;
      if (seg[0] === 'p' && seg[1]) id = seg[1];
      else if (seg[0] === me && seg[1] === 'p' && seg[2]) id = seg[2];
      if (id) { try { B.addOwnPost(id); } catch (err2) {} }
    }

    if (!allowed(url.pathname)) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }
  ['click', 'auxclick'].forEach(function (type) {
    document.addEventListener(type, filterTap, true);
  });

  // ---------- Styling: hide feed entry points, spinners and motion ----------
  var css =
    'a[href="/"], a[href^="/explore"], a[href^="/reels"], a[href*="/reel/"],' +
    'a[href$="/reels/"], a[href$="/reposts/"], a[href$="/tagged/"],' +
    'a[href^="/stories/highlights/"], a[href^="/accounts/activity"],' +
    'a:has(svg[aria-label="Search"]), a:has(svg[aria-label="Notifications"]),' +
    'a:has(svg[aria-label="New post"]), a:has(svg[aria-label="Reels"]),' +
    'a:has(svg[aria-label="Explore"]), a:has(svg[aria-label="Home"]),' +
    '[role="progressbar"], svg[aria-label^="Loading"],' +
    '[data-visualcompletion="loading-state"] { display: none !important; }' +
    '*, *::before, *::after { animation-duration: 0.001s !important;' +
    ' animation-iteration-count: 1 !important; transition-duration: 0s !important;' +
    ' scroll-behavior: auto !important; }' +
    'html.dmonly-chats video { display: none !important; }' +
    '#dmonly-btn { position: fixed; right: 16px; bottom: 76px; z-index: 99999;' +
    ' height: 32px; padding: 0 16px; border: 0; border-radius: 8px;' +
    ' background: #efefef; color: #000; font-weight: 600; font-size: 14px; line-height: 32px;' +
    ' font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }' +
    '#dmonly-shade { position: fixed; inset: 0; z-index: 99998; background: rgba(0,0,0,0.5); }' +
    '#dmonly-panel { position: fixed; left: 0; right: 0; bottom: 0; z-index: 99999;' +
    ' max-height: 70vh; overflow-y: auto; padding: 8px 0 16px; border-radius: 12px 12px 0 0;' +
    ' background: #fff; color: #000; font-size: 14px;' +
    ' font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }' +
    '#dmonly-panel .grip { width: 36px; height: 4px; margin: 4px auto 8px; border-radius: 2px; background: #dbdbdb; }' +
    '#dmonly-panel h2 { margin: 0; padding: 8px 16px 12px; font-size: 16px; font-weight: 700; text-align: center;' +
    ' border-bottom: 1px solid #dbdbdb; }' +
    '#dmonly-panel a { display: flex; align-items: center; gap: 12px; padding: 8px 16px;' +
    ' color: #000; font-weight: 600; text-decoration: none; }' +
    '#dmonly-panel a span { flex: none; width: 44px; height: 44px; border-radius: 50%; background: #efefef;' +
    ' color: #737373; font-size: 18px; line-height: 44px; text-align: center; text-transform: uppercase; }' +
    '#dmonly-panel a.mine { margin-top: 8px; padding-top: 16px; border-top: 1px solid #dbdbdb; }' +
    '#dmonly-panel p { margin: 0; padding: 16px; color: #737373; text-align: center; }' +
    '@media (prefers-color-scheme: dark) {' +
    ' #dmonly-btn { background: #262626; color: #f5f5f5; }' +
    ' #dmonly-panel { background: #262626; color: #f5f5f5; }' +
    ' #dmonly-panel a { color: #f5f5f5; }' +
    ' #dmonly-panel a span { background: #363636; color: #a8a8a8; }' +
    ' #dmonly-panel .grip { background: #555; }' +
    ' #dmonly-panel h2, #dmonly-panel a.mine { border-color: #363636; }' +
    ' #dmonly-panel p { color: #a8a8a8; } }';

  function addStyle() {
    if (document.getElementById('dmonly-style')) return;
    var root = document.head || document.documentElement;
    if (!root) return;
    var style = document.createElement('style');
    style.id = 'dmonly-style';
    style.textContent = css;
    root.appendChild(style);
  }

  // ---------- Learn who is in your chats (chat header only) ----------
  function isVisibleHeaderLink(a) {
    var r = a.getBoundingClientRect();
    if (r.width === 0 || r.height === 0 || r.top < 0 || r.top > 140) return false;
    var el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    return !!el && a.contains(el);
  }
  function scanChatUsers() {
    if (location.pathname.indexOf('/direct/t/') !== 0) return;
    var links = document.querySelectorAll('a[href]');
    for (var i = 0; i < links.length; i++) {
      var m = /^\/([A-Za-z0-9._]+)\/?$/.exec(links[i].getAttribute('href') || '');
      if (!m || !isVisibleHeaderLink(links[i])) continue;
      try { B.addChatUser(m[1]); } catch (e) {}
    }
  }

  // ---------- Stories list (inbox only) ----------
  function closePanel() {
    var panel = document.getElementById('dmonly-panel');
    var shade = document.getElementById('dmonly-shade');
    if (panel) panel.remove();
    if (shade) shade.remove();
  }
  function row(href, label, cls) {
    var a = document.createElement('a');
    a.href = href;
    if (cls) a.className = cls;
    var dot = document.createElement('span');
    dot.textContent = label.charAt(0);
    a.appendChild(dot);
    a.appendChild(document.createTextNode(label));
    return a;
  }
  function togglePanel() {
    if (document.getElementById('dmonly-panel')) { closePanel(); return; }
    var st = state();
    var shade = document.createElement('div');
    shade.id = 'dmonly-shade';
    shade.addEventListener('click', closePanel);
    var panel = document.createElement('div');
    panel.id = 'dmonly-panel';
    var grip = document.createElement('div');
    grip.className = 'grip';
    panel.appendChild(grip);
    var title = document.createElement('h2');
    title.textContent = 'Stories';
    panel.appendChild(title);
    var names = (st.users || []).slice().sort();
    if (!names.length) {
      var p = document.createElement('p');
      p.textContent = 'Open a chat first. People appear here after you open their chat.';
      panel.appendChild(p);
    }
    names.forEach(function (name) {
      panel.appendChild(row('/stories/' + name + '/', name, ''));
    });
    if (st.me) panel.appendChild(row('/' + st.me + '/', 'My profile', 'mine'));
    document.body.appendChild(shade);
    document.body.appendChild(panel);
  }
  function updateButton() {
    if (!document.body) return;
    var onInbox = /^\/direct\/inbox\/?$/.test(location.pathname);
    var btn = document.getElementById('dmonly-btn');
    if (onInbox && !btn) {
      btn = document.createElement('button');
      btn.id = 'dmonly-btn';
      btn.type = 'button';
      btn.textContent = 'Stories';
      btn.addEventListener('click', togglePanel);
      document.body.appendChild(btn);
    } else if (!onInbox) {
      if (btn) btn.remove();
      closePanel();
    }
  }

  function tick() {
    addStyle();
    scanChatUsers();
    updateButton();
  }
  addStyle();
  sweepVideos();
  setInterval(tick, 1000);
})();
