(function () {
  'use strict';
  if (window.__dmonly || !window.DMOnly) return;
  window.__dmonly = true;

  var B = window.DMOnly;
  var HOME = '/direct/inbox/';

  function allowed(path) {
    try { return B.isAllowed(path); } catch (e) { return true; }
  }
  function state() {
    try { return JSON.parse(B.state()); } catch (e) { return { me: '', users: [] }; }
  }
  function segments(path) {
    return path.split('/').filter(Boolean).map(function (s) { return s.toLowerCase(); });
  }
  function onOwnProfile(me) {
    var seg = segments(location.pathname);
    return !!me && seg.length === 1 && seg[0] === me;
  }

  // ---------- Route guard (the app also enforces this natively) ----------
  var leaving = false;
  function guard() {
    if (leaving || allowed(location.pathname)) return;
    leaving = true;
    try { document.documentElement.style.visibility = 'hidden'; } catch (e) {}
    location.replace(HOME);
  }
  ['pushState', 'replaceState'].forEach(function (fn) {
    var original = history[fn];
    history[fn] = function () {
      var result = original.apply(this, arguments);
      guard();
      return result;
    };
  });
  window.addEventListener('popstate', guard);
  window.addEventListener('hashchange', guard);
  setInterval(guard, 200);
  guard();

  // ---------- Tap filter: blocked links do nothing ----------
  function filterTap(e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a || a.closest('#dmonly-panel')) return;
    var url;
    try { url = new URL(a.getAttribute('href'), location.href); } catch (err) { return; }
    if (url.origin !== location.origin) return;

    // Posts become openable only when tapped from your own profile grid
    var me = state().me;
    if (onOwnProfile(me)) {
      var seg = segments(url.pathname);
      var id = null;
      if (seg[0] === 'p' && seg[1]) id = seg[1];
      else if (seg[0] === me && seg[1] === 'p' && seg[2]) id = seg[2];
      if (id) { try { B.addOwnPost(id); } catch (err2) {} }
    }

    if (!allowed(url.pathname)) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }
  ['click', 'auxclick'].forEach(function (type) {
    document.addEventListener(type, filterTap, true);
  });

  // ---------- Styling: hide feed entry points, spinners and motion ----------
  var css =
    'a[href="/"], a[href^="/explore"], a[href^="/reels"], a[href*="/reel/"],' +
    'a[href$="/reels/"], a[href$="/reposts/"], a[href$="/tagged/"],' +
    'a[href^="/stories/highlights/"], a[href^="/accounts/activity"],' +
    'a:has(svg[aria-label="Search"]), a:has(svg[aria-label="Notifications"]),' +
    'a:has(svg[aria-label="New post"]), a:has(svg[aria-label="Reels"]),' +
    'a:has(svg[aria-label="Explore"]), a:has(svg[aria-label="Home"]),' +
    '[role="progressbar"], svg[aria-label^="Loading"],' +
    '[data-visualcompletion="loading-state"] { display: none !important; }' +
    '*, *::before, *::after { animation-duration: 0.001s !important;' +
    ' animation-iteration-count: 1 !important; transition-duration: 0s !important;' +
    ' scroll-behavior: auto !important; }' +
    '#dmonly-btn { position: fixed; right: 12px; bottom: 72px; z-index: 99999;' +
    ' padding: 8px 12px; border: 1px solid #888; border-radius: 6px;' +
    ' background: #fff; color: #000; font: 14px sans-serif; }' +
    '#dmonly-panel { position: fixed; right: 12px; bottom: 116px; z-index: 99999;' +
    ' max-height: 60vh; overflow-y: auto; min-width: 180px; padding: 8px;' +
    ' border: 1px solid #888; border-radius: 6px; background: #fff; color: #000;' +
    ' font: 14px sans-serif; }' +
    '#dmonly-panel a { display: block; padding: 10px 4px; color: #000; text-decoration: none; }' +
    '#dmonly-panel p { margin: 4px; color: #555; }' +
    '@media (prefers-color-scheme: dark) {' +
    ' #dmonly-btn, #dmonly-panel { background: #000; color: #fff; }' +
    ' #dmonly-panel a { color: #fff; } #dmonly-panel p { color: #aaa; } }';

  function addStyle() {
    if (document.getElementById('dmonly-style')) return;
    var root = document.head || document.documentElement;
    if (!root) return;
    var style = document.createElement('style');
    style.id = 'dmonly-style';
    style.textContent = css;
    root.appendChild(style);
  }

  // ---------- Learn who is in your chats (chat header only) ----------
  function isVisibleHeaderLink(a) {
    var r = a.getBoundingClientRect();
    if (r.width === 0 || r.height === 0 || r.top < 0 || r.top > 140) return false;
    var el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    return !!el && a.contains(el);
  }
  function scanChatUsers() {
    if (location.pathname.indexOf('/direct/t/') !== 0) return;
    var links = document.querySelectorAll('a[href]');
    for (var i = 0; i < links.length; i++) {
      var m = /^\/([A-Za-z0-9._]+)\/?$/.exec(links[i].getAttribute('href') || '');
      if (!m || !isVisibleHeaderLink(links[i])) continue;
      try { B.addChatUser(m[1]); } catch (e) {}
    }
  }

  // ---------- Stories list (inbox only) ----------
  function togglePanel() {
    var existing = document.getElementById('dmonly-panel');
    if (existing) { existing.remove(); return; }
    var st = state();
    var panel = document.createElement('div');
    panel.id = 'dmonly-panel';
    var names = (st.users || []).slice().sort();
    if (!names.length) {
      var p = document.createElement('p');
      p.textContent = 'Open a chat first. People appear here after you open their chat.';
      panel.appendChild(p);
    }
    names.forEach(function (name) {
      var a = document.createElement('a');
      a.href = '/stories/' + name + '/';
      a.textContent = name;
      panel.appendChild(a);
    });
    if (st.me) {
      var mine = document.createElement('a');
      mine.href = '/' + st.me + '/';
      mine.textContent = 'My profile';
      panel.appendChild(mine);
    }
    document.body.appendChild(panel);
  }
  function updateButton() {
    if (!document.body) return;
    var onInbox = /^\/direct\/inbox\/?$/.test(location.pathname);
    var btn = document.getElementById('dmonly-btn');
    if (onInbox && !btn) {
      btn = document.createElement('button');
      btn.id = 'dmonly-btn';
      btn.type = 'button';
      btn.textContent = 'Stories';
      btn.addEventListener('click', togglePanel);
      document.body.appendChild(btn);
    } else if (!onInbox) {
      if (btn) btn.remove();
      var panel = document.getElementById('dmonly-panel');
      if (panel) panel.remove();
    }
  }

  function tick() {
    addStyle();
    scanChatUsers();
    updateButton();
  }
  addStyle();
  setInterval(tick, 1000);
})();
