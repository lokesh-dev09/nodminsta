package app.dmonly;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {

    // ---------- Settings ----------
    private static final boolean OWN_POSTS = true;   // false = your own posts cannot be opened either
    private static final String HOME = "https://www.instagram.com/direct/inbox/";
    // ------------------------------

    private static final int FILE_REQUEST = 1;
    private static final String NAME_PATTERN = "[a-z0-9._]{1,30}";

    // Pages Instagram needs for login, security checks and settings
    private static final List<String> SYSTEM = Arrays.asList(
            "direct", "accounts", "challenge", "two_factor", "legal", "oauth");
    // First path segments that are never usernames
    private static final List<String> RESERVED = Arrays.asList(
            "direct", "accounts", "challenge", "two_factor", "legal", "oauth",
            "explore", "reels", "reel", "p", "stories", "tv", "about", "developer",
            "directory", "web", "api", "graphql", "static", "emails", "privacy", "terms");

    private WebView web;
    private SharedPreferences prefs;
    private String injectJs = "";
    private volatile String me = "";
    private Set<String> chatUsers;
    private Set<String> ownPosts;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("dmonly", MODE_PRIVATE);
        me = prefs.getString("me", "");
        chatUsers = Collections.synchronizedSet(
                new HashSet<String>(prefs.getStringSet("chatUsers", new HashSet<String>())));
        ownPosts = Collections.synchronizedSet(
                new HashSet<String>(prefs.getStringSet("ownPosts", new HashSet<String>())));
        injectJs = readAsset("inject.js");

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "DMOnly");
        web.setWebViewClient(new Guard());
        web.setWebChromeClient(new Chrome());

        if (savedInstanceState == null) {
            web.loadUrl(HOME);
        } else {
            web.restoreState(savedInstanceState);
        }

        if (me.isEmpty()) {
            askForUsername();
        }
    }

    // ---------- The single rule everything relies on ----------
    private static List<String> segments(String path) {
        List<String> out = new ArrayList<String>();
        if (path == null) return out;
        for (String part : path.split("/")) {
            if (!part.isEmpty()) out.add(part.toLowerCase(Locale.ROOT));
        }
        return out;
    }

    private boolean isAllowedPath(String path) {
        List<String> seg = segments(path);
        if (seg.isEmpty()) return false;                                   // home feed
        String first = seg.get(0);
        String mine = me;

        if (first.equals("accounts")) {                                    // notifications page links out to posts
            return !(seg.size() > 1 && seg.get(1).equals("activity"));
        }
        if (SYSTEM.contains(first)) return true;

        if (first.equals("stories")) {                                     // /stories/<username>/...
            if (seg.size() < 2) return false;
            String who = seg.get(1);
            return (!mine.isEmpty() && who.equals(mine)) || chatUsers.contains(who);
        }
        if (first.equals("p")) {                                           // only posts tapped from your own grid
            return OWN_POSTS && seg.size() > 1 && ownPosts.contains(seg.get(1));
        }
        if (!mine.isEmpty() && first.equals(mine)) {
            if (seg.size() == 1) return true;                              // your profile itself
            return OWN_POSTS && seg.size() > 2 && seg.get(1).equals("p")
                    && ownPosts.contains(seg.get(2));
        }
        return false;                                                      // reels, explore, other profiles, the rest
    }

    private static boolean isInstagram(String host) {
        return host != null && (host.equals("www.instagram.com") || host.equals("instagram.com"));
    }

    private void saveSet(String key, Set<String> set) {
        Set<String> copy;
        synchronized (set) {
            copy = new HashSet<String>(set);
        }
        prefs.edit().putStringSet(key, copy).apply();
    }

    // ---------- Navigation guard ----------
    private class Guard extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            if (!request.isForMainFrame()) return false;
            Uri uri = request.getUrl();
            String scheme = uri.getScheme();
            if (!"https".equals(scheme) && !"http".equals(scheme)) return true;   // never hand off to other apps
            if (!isInstagram(uri.getHost())) {
                openExternally(uri);                                              // ordinary web links go to your browser
                return true;
            }
            if (!isAllowedPath(uri.getPath())) {
                if (request.isRedirect()) view.loadUrl(HOME);                     // e.g. login landing on the feed
                return true;                                                      // a tap on a blocked link does nothing
            }
            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            enforce(view, url);
        }

        @Override
        public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
            enforce(view, url);                                                   // also fires for in-page navigation
            inject(view);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            enforce(view, url);
            inject(view);
        }
    }

    private void enforce(final WebView view, String url) {
        if (url == null) return;
        Uri uri = Uri.parse(url);
        if (!isInstagram(uri.getHost())) return;
        if (!isAllowedPath(uri.getPath())) {
            view.post(new Runnable() {
                @Override
                public void run() {
                    view.loadUrl(HOME);
                }
            });
        }
    }

    private void inject(WebView view) {
        if (!injectJs.isEmpty()) view.evaluateJavascript(injectJs, null);
    }

    private void openExternally(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
        }
    }

    // ---------- Photo/file picker for sending things in chats ----------
    private class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            try {
                startActivityForResult(params.createIntent(), FILE_REQUEST);
            } catch (ActivityNotFoundException e) {
                fileCallback = null;
                callback.onReceiveValue(null);
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            fileCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    // ---------- Bridge used by inject.js ----------
    private class Bridge {

        @JavascriptInterface
        public boolean isAllowed(String path) {
            return isAllowedPath(path);
        }

        @JavascriptInterface
        public void addChatUser(String name) {
            if (name == null) return;
            String n = name.toLowerCase(Locale.ROOT);
            if (!n.matches(NAME_PATTERN) || RESERVED.contains(n) || n.equals(me)) return;
            if (chatUsers.add(n)) saveSet("chatUsers", chatUsers);
        }

        @JavascriptInterface
        public void addOwnPost(String id) {
            if (id == null) return;
            String p = id.toLowerCase(Locale.ROOT);
            if (!p.matches("[a-z0-9_-]{1,64}")) return;
            if (ownPosts.add(p)) saveSet("ownPosts", ownPosts);
        }

        @JavascriptInterface
        public String state() {
            try {
                JSONObject o = new JSONObject();
                o.put("me", me);
                JSONArray users = new JSONArray();
                synchronized (chatUsers) {
                    for (String u : chatUsers) users.put(u);
                }
                o.put("users", users);
                return o.toString();
            } catch (Exception e) {
                return "{\"me\":\"\",\"users\":[]}";
            }
        }
    }

    // ---------- First launch: which profile is yours ----------
    private void askForUsername() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setHint("username");
        new AlertDialog.Builder(this)
                .setTitle("Your Instagram username")
                .setMessage("So your own profile stays viewable. Everything else stays blocked.")
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("Save", (dialog, which) -> {
                    String value = input.getText().toString().trim().toLowerCase(Locale.ROOT);
                    if (value.startsWith("@")) value = value.substring(1);
                    if (value.matches(NAME_PATTERN)) {
                        me = value;
                        prefs.edit().putString("me", value).apply();
                    }
                })
                .setNegativeButton("Skip", null)
                .show();
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }
}
